import time

logs = []

def log_interaction(user, message, response):
    logs.append({
        "user": user,
        "message": message,
        "response": response,
        "timestamp": time.time()
    })
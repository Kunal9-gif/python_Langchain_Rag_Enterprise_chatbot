from langchain.tools import Tool
import requests

def get_system_status():
    return requests.get("https://status.aws.amazon.com").text[:500]

TOOLS = [
    Tool(
        name="AWSStatusChecker",
        func=get_system_status,
        description="Checks AWS service status"
    )
]
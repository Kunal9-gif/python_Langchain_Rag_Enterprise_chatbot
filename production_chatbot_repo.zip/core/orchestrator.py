from langchain.agents import initialize_agent, AgentType
from core.llm import llm
from core.tools import TOOLS
from core.memory import retrieve_memory, store_memory

def chatbot_pipeline(user_input):
    context = retrieve_memory(user_input)
    agent = initialize_agent(
        tools=TOOLS,
        llm=llm,
        agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        verbose=True
    )
    response = agent.run(f"Context: {context}\nQuestion: {user_input}")
    store_memory(user_input + response)
    return response
from langchain.vectorstores import Pinecone
from langchain.embeddings.openai import OpenAIEmbeddings
import pinecone

pinecone.init(api_key="YOUR_PINECONE_API_KEY", environment="us-east1-gcp")
index_name = "chatbot-memory"
embeddings = OpenAIEmbeddings()
vectorstore = Pinecone.from_existing_index(index_name=index_name, embedding=embeddings)

def store_memory(text, metadata=None):
    vectorstore.add_texts([text], metadatas=[metadata])

def retrieve_memory(query):
    docs = vectorstore.similarity_search(query, k=3)
    return "\n".join([d.page_content for d in docs])
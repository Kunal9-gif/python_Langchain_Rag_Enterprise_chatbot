from langchain.chat_models import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage
from core.prompt import SYSTEM_PROMPT

llm = ChatOpenAI(model_name="gpt-4-turbo", temperature=0.3)

def generate_response(user_input):
    messages = [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=user_input)]
    return llm(messages).content